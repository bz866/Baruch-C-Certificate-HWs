#include <stdio.h>
#include "Multiply.hpp"

int main(){
	double n;

	printf("Enter a number: \n");
	scanf("%lf", &n); //Get the input

	print(n);

	return 0;
}