//The header file for Main.c and Print.c

#ifndef Multiply
#define Multiply

void print();

#endif