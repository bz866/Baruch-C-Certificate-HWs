#include <stdio.h>

void print(double n)
{
	double res;

	res = n * 2.0;

	printf("The result of multiplying by 2 is: %f \n", res);
}