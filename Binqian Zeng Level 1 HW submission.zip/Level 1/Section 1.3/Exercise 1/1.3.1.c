#include <stdio.h>

int main() {
	/*
	C-program that prints a message 
	*/
	printf("My first C-program\n");
	printf("is a fact!\n");
	printf("Good, isn't it?");

	return 0; // 0 represents no error
}